package sample.contact

class Contact implements Serializable {

	String email
	String name

	@Override
	String toString() {
		"${super.toString()}: Id: $id; Name: $name; Email: $email"
	}

	static constraints = {
		email size: 3..50
		name size: 3..50
	}
}
