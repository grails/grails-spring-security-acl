/*
grails.config.locations = ["classpath:${appName}-config.groovy", "file:./${appName}-config.groovy"]
if (System.properties["${appName}.config.location"]) {
	grails.config.locations << 'file:' + System.properties["${appName}.config.location"]
}
*/

grails.project.groupId = appName
grails.mime.file.extensions = true
grails.mime.use.accept.header = false
grails.mime.use.accept.header = false
grails.mime.types = [
	all:           '*/*',
	atom:          'application/atom+xml',
	css:           'text/css',
	csv:           'text/csv',
	form:          'application/x-www-form-urlencoded',
	html:          ['text/html','application/xhtml+xml'],
	js:            'text/javascript',
	json:          ['application/json', 'text/json'],
	multipartForm: 'multipart/form-data',
	rss:           'application/rss+xml',
	text:          'text/plain',
	xml:           ['text/xml', 'application/xml']
]

grails.resources.adhoc.patterns = ['/images/*', '/css/*', '/js/*', '/plugins/*']
grails.views.default.codec = 'html'
grails.views.gsp.encoding = 'UTF-8'
grails.converters.encoding = 'UTF-8'
grails.views.gsp.sitemesh.preprocess = true
grails.scaffolding.templates.domainSuffix = ''
grails.json.legacy.builder = false
grails.enable.native2ascii = true
grails.spring.bean.packages = []
grails.web.disable.multipart = false
grails.exceptionresolver.params.exclude = ['password']
grails.hibernate.cache.queries = false

grails.dbconsole.enabled = true

environments {
	development {
		grails.logging.jul.usebridge = true
	}
	production {
		grails.logging.jul.usebridge = false
	}
}

log4j = {
	error 'org.codehaus.groovy.grails',
	      'org.springframework',
	      'org.hibernate',
	      'net.sf.ehcache.hibernate'
	debug 'org.hibernate.SQL'
//	trace 'org.hibernate.type.descriptor.sql.BasicBinder'
}



grails.plugin.springsecurity.userLookup.userDomainClassName = 'sample.contact.auth.User'
grails.plugin.springsecurity.userLookup.authorityJoinClassName = 'sample.contact.auth.UserRole'
grails.plugin.springsecurity.authority.className = 'sample.contact.auth.Role'
grails.plugin.springsecurity.controllerAnnotations.staticRules = [
	'/':                              ['permitAll'],
	'/index':                         ['permitAll'],
	'/index.gsp':                     ['permitAll'],
	'/**/js/**':                      ['permitAll'],
	'/**/css/**':                     ['permitAll'],
	'/**/images/**':                  ['permitAll'],
	'/**/favicon.ico':                ['permitAll'],

	'/j_spring_security_switch_user': ['ROLE_SUPERVISOR'],
	'/**':                            ['ROLE_USER']
]

grails.plugin.springsecurity.useSwitchUserFilter = true
grails.plugin.springsecurity.switchUser.targetUrl = '/secure/'
grails.plugin.springsecurity.adh.errorPage = null // to trigger a 403
