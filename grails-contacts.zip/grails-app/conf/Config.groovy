grails.project.groupId = appName
grails.mime.file.extensions = false
grails.mime.use.accept.header = false
grails.mime.types = [
	html: ['text/html','application/xhtml+xml'],
	xml: ['text/xml', 'application/xml'],
	text: 'text/plain',
	js: 'text/javascript',
	rss: 'application/rss+xml',
	atom: 'application/atom+xml',
	css: 'text/css',
	csv: 'text/csv',
	all: '*/*',
	json: ['application/json','text/json'],
	form: 'application/x-www-form-urlencoded',
	multipartForm: 'multipart/form-data'
]

grails.views.default.codec = 'html'
grails.views.gsp.encoding = 'UTF-8'
grails.converters.encoding = 'UTF-8'
grails.views.gsp.sitemesh.preprocess = true
grails.scaffolding.templates.domainSuffix = 'Instance'

grails.json.legacy.builder = false
grails.enable.native2ascii = true
grails.logging.jul.usebridge = true
grails.spring.bean.packages = []

environments {
	production {
		grails.serverURL = 'http://www.changeme.com'
	}
	development {
		grails.serverURL = "http://localhost:8080/${appName}"
	}
	test {
		grails.serverURL = "http://localhost:8080/${appName}"
	}
}

log4j = {

	error  'org.codehaus.groovy.grails.web.servlet',
	       'org.codehaus.groovy.grails.web.pages',
	       'org.codehaus.groovy.grails.web.sitemesh',
	       'org.codehaus.groovy.grails.web.mapping.filter',
	       'org.codehaus.groovy.grails.web.mapping',
	       'org.codehaus.groovy.grails.commons',
	       'org.codehaus.groovy.grails.plugins',
	       'org.codehaus.groovy.grails.orm.hibernate',
	       'org.springframework',
	       'org.hibernate',
	       'net.sf.ehcache.hibernate'

	warn   'org.mortbay.log'
}

grails.plugins.springsecurity.userLookup.userDomainClassName = 'sample.contact.User'
grails.plugins.springsecurity.userLookup.authorityJoinClassName = 'sample.contact.UserRole'
grails.plugins.springsecurity.authority.className = 'sample.contact.Role'

grails.plugins.springsecurity.useSwitchUserFilter = true
grails.plugins.springsecurity.switchUser.targetUrl = '/secure/'

grails.plugins.springsecurity.controllerAnnotations.staticRules = [
	'/':                              ['permitAll'],
	'/index.gsp':                     ['permitAll'],
	'/js/**':                         ['permitAll'],
	'/css/**':                        ['permitAll'],
	'/images/**':                     ['permitAll'],
	'/j_spring_security_switch_user': ['ROLE_SUPERVISOR'],
	'/**':                            ['ROLE_USER']
]

grails.plugins.springsecurity.adh.errorPage = null // to trigger a 403
