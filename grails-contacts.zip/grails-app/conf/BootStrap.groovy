import sample.contact.DataSourcePopulator

class BootStrap {

	def grailsApplication

	def init = { servletContext ->
		new DataSourcePopulator().populate grailsApplication.mainContext
	}
}
