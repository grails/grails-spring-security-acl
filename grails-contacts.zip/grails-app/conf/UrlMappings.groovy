class UrlMappings {

	static mappings = {
		"/$controller/$action?/$id?"{
			constraints {}
		}

		"/"(controller: "hello")
		"/index.gsp"(view: "hello")

		"403"(controller: "errors", action: "error403")
		"404"(controller: "errors", action: "error404")
		"500"(controller: "errors", action: "error500")
	}
}
